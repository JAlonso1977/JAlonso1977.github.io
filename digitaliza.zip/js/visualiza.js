/*Name this external file gallery.js*/
/*Jesús Alonso Week 2 assingment */

function inicia(){
    document.getElementById('salud').style.display="block";
	}

  function salud(){
      document.getElementById('calidad').style.display="block";
  	}

  function calidad(){
      document.getElementById('breeam0').style.display="block";
    }
  function breeamSi(){
        document.getElementById('breeam').style.display="block";
    	}
  function breeamNo(){
        document.getElementById('bim0').style.display="block";
      }
  function bimSi(){
        document.getElementById('bim').style.display="block";
      }
  function bimNo(){
        document.getElementById('lean0').style.display="block";
      }
function leanSi(){
      document.getElementById('lean').style.display="block";
      }
function leanNo(){
      document.getElementById('aemet0').style.display="block";
      }
function aemetSi(){
      document.getElementById('aemet').style.display="block";
      }
function aemetNo(){
      document.getElementById('perso0').style.display="block";
      }
function persoSi(){
      document.getElementById('perso').style.display="block";
      }
function persoNo(){
      document.getElementById('fin').style.display="block";
      }
